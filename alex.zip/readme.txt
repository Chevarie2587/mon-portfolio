
Je suis Alex Chevarie, un développeur passionné ayant récemment terminé ma formation en technique en informatique, spécialisation en conception et programmation, en mai 2023. Actuellement, je travaille à temps plein chez DRC Solutions, où je contribue à la conception et à la mise en œuvre de solutions innovantes pour nos clients.

Grâce à mon expérience chez DRC Solutions, j'ai perfectionné mes compétences techniques et acquis une solide expérience professionnelle. Je suis passionné par les nouvelles technologies, l'innovation et l'apprentissage continu.

Mon portfolio regroupe des projets intéressants à consulter que j'ai réalisé au cours des dernières années :


Je suis convaincu que mon engagement, ma créativité et ma passion font de moi un atout pour toute équipe de développement.

Au plaisir de collaborer avec vous,

Alex Chevarie
